

#include <stdio.h>
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>

int main(){

    int fd, ret;
    ssize_t n, m;
    char buf[4096];
    struct sockaddr_in my_addr;
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = 4567;
    my_addr.sin_addr.s_addr = htonl((192 << 24) | (168 << 16) | (162 << 8) | 223);

    // Open a socket
    fd = socket( AF_INET, SOCK_DGRAM, 0);
    if( fd == -1 ){
        fprintf(stderr, "socket() fail\n");
        fprintf(stderr, "errno: %s\n", strerror(errno));
        return -1;
    }

    // bind the socket
    ret = bind( fd, (struct sockaddr*) &my_addr, sizeof(struct sockaddr_in));
    if( -1 == ret ){
        fprintf(stderr, "bind() fail\n");
        fprintf(stderr, "errno: %s\n", strerror(errno));
        return -1;
    }

#define FILE_SIZE (100*4096)

    int to_receive = FILE_SIZE;
    FILE * file_p;

    file_p = fopen("recv.bin", "w+");
    assert( file_p != NULL );

    while(to_receive){

        fprintf(stderr, "left: %d\n", to_receive);

        n = recv( fd, buf, 4096, 0 );
        assert(n == 4096);

        m = fwrite( buf, 1, 4096, file_p );
        assert(m == 4096);

        to_receive -= 4096;
    }

    // Read

    fclose(file_p);
    close(fd);

    return 0;
}


