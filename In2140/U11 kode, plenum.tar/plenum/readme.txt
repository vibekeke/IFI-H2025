To build: make

The sender and receiver have hardcoded IP addresses. These worked in the setup
from the plenum lecture, which had two laptops connected with wifi and ethernet.

You don't need two machines to test this. All Linux machines have a loopback
interface which is called 'lo'. You will see it if you run 'ifconfig' on any
Linux machine. The loopback interface normally has IP address 127.0.0.1 (I have
never ever seen anything else anywhere, so I assume this is fairly standard). As
an example, here is my loopback interface on my machine (output from
'ifconfig'):

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 2786  bytes 267401 (267.4 KB)
        RX errors 0  dropped 0  overruns 0  frame 0
        TX packets 2786  bytes 267401 (267.4 KB)
        TX errors 0  dropped 0 overruns 0  carrier 0  collisions 0

To test with the loopback device, do as follows:
 - sender.c: change the IP addresses to 127.0.0.1
 - receiver.c: change the IP address to 127.0.0.1
 - make

That is all required to build. Notice the two new files, receiver and sender:

robin@gimli:> ls -l
total 440
-rw-rw-r-- 1 robin robin    158 Mar 14 07:57 Makefile
-rwxrwxr-x 1 robin robin  16576 Mar 14 08:06 receiver    << THIS
-rw-rw-r-- 1 robin robin   1343 Mar 13 15:40 receiver.c
-rw-rw-r-- 1 robin robin 397312 Mar 13 15:44 recv.bin
-rwxrwxr-x 1 robin robin  16592 Mar 14 08:06 sender      << THIS
-rw-rw-r-- 1 robin robin   1539 Mar 13 15:39 sender.c


The software transmits a file called "file.bin". It needs to be in the same
directory as the executables (receiver and sender). I don't want to upload large
files containing nothing useful, so you must generate it yourself. Do:

dd if=/dev/urandom of=file.bin bs=4096 count=100
(Notice: change the count if you change the multiplier for enum FILE_SIZE).

This will generate a completely random file called file.bin in your current
working directory.

To run. Open two terminals and navigate to wherever you ran make.
 - In terminal 1: ./receiver
 - In terminal 2: ./sender

Once the program is done transmitting, the receiver will store the file in
recv.bin. To check that the transmitted and received file is the same, you can
do:
 - vimdiff file.bin recv.bin
 - or use md5sum. md5sum file.bin and md5sum recv.bin should be the same.

Final notice: This example uses UDP, so packets can get lost if you test it over
wifi or ethernet. However, it should be fine with the loopback device.

Good luck!
