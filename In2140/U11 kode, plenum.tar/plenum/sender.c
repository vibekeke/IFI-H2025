

#include <stdio.h>
#include <sys/socket.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>

int main(){

    int fd, ret;
    ssize_t n, m;
    char buf[4096];
    struct sockaddr_in my_addr;
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = 4567;
    my_addr.sin_addr.s_addr = htonl((192 << 24) | (168 << 16) | (162 << 8) | 3);

    struct sockaddr_in their_addr;
    their_addr.sin_family = AF_INET;
    their_addr.sin_port = 4567;
    their_addr.sin_addr.s_addr = htonl((192 << 24) | (168 << 16) | (162 << 8) | 223);


    // Open a socket
    fd = socket( AF_INET, SOCK_DGRAM, 0);
    if( fd == -1 ){
        fprintf(stderr, "socket() fail\n");
        fprintf(stderr, "errno: %s\n", strerror(errno));
        return -1;
    }

    // bind the socket
    ret = bind( fd, (struct sockaddr*) &my_addr, sizeof(struct sockaddr_in));
    if( -1 == ret ){
        fprintf(stderr, "bind() fail\n");
        fprintf(stderr, "errno: %s\n", strerror(errno));
        return -1;
    }

#define FILE_SIZE (100*4096)

    int to_send = FILE_SIZE;
    FILE * file_fd;

    file_fd = fopen("file.bin", "r");
    assert( file_fd >= 0 );

    while(to_send){

        m = fread( buf, 1, 4096, file_fd );
        assert(m == 4096);

        n = sendto( fd, buf, 4096, 0,
                    (struct sockaddr*) &their_addr,
                    sizeof(struct sockaddr_in));
        assert(n == 4096);

        to_send -= 4096;
    }

    close(fd);

    return 0;
}


