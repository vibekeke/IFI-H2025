
#define SIZE 30000

int data[SIZE][SIZE];

int main(){

    int i, j;

    for(j = 0; j < SIZE; j++){
        for(i=0; i < SIZE; i++){

            data[j][i] = i*j;
        }
    }

    return 0;
}
