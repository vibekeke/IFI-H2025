
#include <stdio.h>


int main(){

    int a = 0;

    if( a = 1 ){
        fprintf(stderr, "a is 1\n");
    }
    else
        fprintf(stderr, "a is not 1\n");

    return 0;
}
