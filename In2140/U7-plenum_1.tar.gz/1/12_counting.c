
#include <unistd.h>
#include <stdio.h>
#include <sched.h>

int main(){
    int i;
    int is_child = 0;
    long long int counter = 0;

    if( fork() == 0 )
        is_child=1;

    while(1){
        counter++;

        if( (counter % 10000000) == 0)
            fprintf(stderr, "%s counter=%lld\n", is_child ? "child" : "parnt", counter);

        if( 0 && is_child)
            sched_yield();
    }
    return 0;
}
