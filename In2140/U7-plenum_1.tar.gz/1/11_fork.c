

#include <unistd.h>
#include <stdio.h>


int i = 0;
int main(){

    fprintf(stderr, "i=%d\n", i);
    fork();
    i++;
    fork();
    i++;
    fork();
    i++;
    fork();
    i++;
    fork();
    i++;

    fprintf(stderr, "i=%d\n", i);

    while(1);

    return 0;
}
