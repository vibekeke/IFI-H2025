
// MACRO
#define SIZE 0x40

int sum_array(char * array){

    int sum = 0, i;

    for(i=0; i < SIZE; i++)
        sum += array[i];

    return sum;
}


int main(){

    int i;
    char array[SIZE];

    for(i=0; i < SIZE; i++)
        array[i] = (char) i;

    return sum_array(array);
}
