

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]){

    int i;
    int res = 0;
    int * array;

    fprintf(stderr, "Usage: %s <number string>\n", argv[0]);
    fprintf(stderr, "This program prints the sum of all the numbers in the"
            " string.\n");

    //for(i=0; i < argc; i++)
    //    fprintf(stderr, "argv[%d]: %s\n", i, argv[i]);

    if( argv[1] == NULL ){
        fprintf(stderr, "Please provide input string.\n");
        return -1;
    }

    fprintf(stderr, "String length: %d\n", strlen(argv[1]));

    array = malloc(strlen(argv[1]) * sizeof(int));

    // First, convert from character to integer
    for(i=0; i < strlen(argv[1]); i++){
        fprintf(stderr, "char%d: %d\n", i, argv[1][i]);
        fprintf(stderr, "the value is: %d\n", argv[1][i] - 48);

        array[i] = argv[1][i] - 48;
    }

    // Second loop computes the sum
    for(i=0; i < strlen(argv[1]); i++){
        res += array[i];
    }

    fprintf(stderr, "res=%d\n", res);

    return 0;
}
