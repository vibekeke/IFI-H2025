
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char * argv[]){

    int i;
    int * array; // pointer!
    int sum = 0;

    for(i=0; i < argc; i++){

        fprintf(stderr, "arg%d : %s\n", i, argv[i]);
    }

    if(argc != 2){
        fprintf(stderr, "Usage: %s <numbers in ascii>\n", argv[0]);
    }

    array = malloc( strlen(argv[1]) * sizeof(int) );

    for(i=0; i < strlen(argv[1]); i++){

        fprintf(stderr, "char%d : %c %d\n", 
                i, argv[1][i], (int) argv[1][i]);

        array[i] = ((int) argv[1][i]) - 48;

        fprintf(stderr, "array[%d]: %d\n",
                i, array[i]);
    }

    for(i=0; i < strlen(argv[1]); i++){
        
        sum += array[i];
    }

    fprintf(stderr, "sum=%d\n", sum);

    free(array);

    return 0;
}
