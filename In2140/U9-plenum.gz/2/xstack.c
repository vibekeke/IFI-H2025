
int main(){

    asm("mov $0xffffffffffffffff, %rax\n"
        "mov %rax, %rsp\n"
        "pop %rax\n"
       );

    return 0;
}
