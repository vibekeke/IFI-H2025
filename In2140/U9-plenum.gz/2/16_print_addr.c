
#include <stdio.h>
#include <stdlib.h>

int main(){

    volatile int * some_ptr = 0;
    some_ptr = malloc(sizeof(int));
    *some_ptr = 0;

    fprintf(stderr, "some_ptr=0x%llx\n", (unsigned long long) some_ptr);

    while( ! (*some_ptr));

    return 0;
}
