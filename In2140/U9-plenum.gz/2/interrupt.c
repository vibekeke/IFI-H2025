
#include <stdio.h>
#include <signal.h>

volatile int keep_going = 1;

void my_handler(int a){
    fprintf(stderr, "I'm in my first handler!\n");
    keep_going = 0;
}

int main(){

    signal( SIGINT, my_handler );

    while(keep_going){

    }


    return 0;

}
