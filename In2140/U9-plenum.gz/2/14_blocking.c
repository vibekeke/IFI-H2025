
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>

int main(){

    int fd;
    int flags;
    int ret;
    char buf[512];

    fd = fileno(stdin);

#if 1 // I really do not want to block
    flags = fcntl(fd, F_GETFL, 0);
    flags |= O_NONBLOCK;
    ret = fcntl(fd, F_SETFL, flags);
    if( ret < 0 ){
        fprintf(stderr, "Could not fcntl.\n");
        return -1;
    }
#endif

    while(1){
        fprintf(stderr, "reading..\n");
        ret = read(fd, buf, 512);
        if( ret < 0 ){
            fprintf(stderr, "Could not read file.\n");
        }
        else{
            fprintf(stderr, "I got this: %s\n", buf);
            break;
        }
    }

    fprintf(stderr, "File was read!\n");

    return 0;
}

