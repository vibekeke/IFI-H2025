

int main(){

    volatile int * a_pointer = (volatile int *) 0x13a32a0;

    *a_pointer = 1;

    while(1);
}
